import express from "express";
const app = express();
const port = 3000;

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
})

let titlesArray = [];
let contentArray = [];
const prefix="post"

function fillPost(currentPost)
{
    $("#" + prefix + currentPost).append(titlesArray[currentPost])
    $("#" + prefix + currentPost).append(contentArray[currentPost])
    $("#" + prefix + currentPost).append("<button id=\"post" + currentPost + "d\" type=\"button\" class=\"btn btn-danger btn-sm\">Delete</button>")
    document.getElementById("post" + currentPost + "d").addEventListener("click", function(){
        deletePost(currentPost)
    });
}

function makeNewPost(){
    let currentPost = contentArray.length;
    titlesArray.push(document.getElementById("newTitle").value);
    contentArray.push(document.getElementById("postContents").value);
    $(".posts").append("Title:<p>" + titlesArray[currentPost] + "<p>");
    $(".posts").append("<div id=\"task" + currentPost + "\" class=\"col-4 text-center text-wrap border border-primary\"> </div>");
    fillPost(currentPost);
}

function deletePost(currentPost)
{
    $("#" + prefix + currentPost).replaceWith("");
}

document.getElementById("submit").addEventListener("click", makeNewPost);